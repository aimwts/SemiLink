import React, { useState, useRef } from 'react';
import { Image, Video, Calendar, MoreHorizontal, Wand2, Send, Loader2, X } from 'lucide-react';
import { CURRENT_USER } from '../constants';
import { generateIndustryInsight, polishPostContent } from '../services/geminiService';
import { Post, User } from '../types';

interface CreatePostProps {
  onPostCreated: (post: Post) => void;
  currentUser?: User;
}

const CreatePost: React.FC<CreatePostProps> = ({ onPostCreated, currentUser }) => {
  const [content, setContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  const [imgError, setImgError] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const user = currentUser || CURRENT_USER;

  const fallbackAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=0369a1&color=fff`;
  const avatarSrc = (imgError || !user.avatarUrl) ? fallbackAvatar : user.avatarUrl;

  const handleGenerate = async () => {
    setIsGenerating(true);
    const topics = ["FinFET Scaling", "Chip Shortage Recovery", "RISC-V Adoption", "Advanced Packaging", "Photonics", "EUV Lithography"];
    const randomTopic = topics[Math.floor(Math.random() * topics.length)];
    const aiText = await generateIndustryInsight(randomTopic);
    setContent(aiText);
    setIsGenerating(false);
  };

  const handlePolish = async () => {
    if (!content.trim()) return;
    setIsGenerating(true);
    const polished = await polishPostContent(content);
    setContent(polished);
    setIsGenerating(false);
  };

  const handleMediaClick = () => {
    fileInputRef.current?.click();
  };

  const handleVideoClick = () => {
    videoInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setSelectedVideo(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedVideo(reader.result as string);
        setSelectedImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeMedia = () => {
    setSelectedImage(null);
    setSelectedVideo(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (videoInputRef.current) videoInputRef.current.value = '';
  };

  const handleEventClick = () => {
    setContent(prev => prev + (prev ? '\n\n' : '') + "📅 Event Invitation:\nTopic: \nDate: \nLocation: \nLink: ");
  };

  const handleSubmit = () => {
    if (!content.trim() && !selectedImage && !selectedVideo) return;

    const newPost: Post = {
      id: Date.now().toString(),
      author: user,
      content: content,
      imageUrl: selectedImage || undefined,
      videoUrl: selectedVideo || undefined,
      likes: 0,
      comments: 0,
      timestamp: 'Just now',
      tags: ['IndustryUpdate']
    };

    onPostCreated(newPost);
    setContent('');
    setSelectedImage(null);
    setSelectedVideo(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (videoInputRef.current) videoInputRef.current.value = '';
  };

  return (
    <div className="bg-[#1e2130] rounded-lg shadow-sm mb-4 border border-gray-700">
      <div className="p-4">
        <div className="flex gap-3">
          <img
            src={avatarSrc}
            alt={user.name}
            className="w-12 h-12 rounded-full object-cover border border-gray-700"
            onError={() => setImgError(true)}
          />
          <div className="flex-1">
            <textarea
              className="w-full border border-gray-600 rounded-lg p-3 bg-[#252a3a] text-gray-100 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-semi-500 resize-none"
              placeholder={`Start a post about chip design, fab updates, or industry trends...`}
              rows={3}
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
            {selectedImage && (
              <div className="relative mt-2 inline-block">
                <img src={selectedImage} alt="Preview" className="max-h-48 rounded-lg border border-gray-700" />
                <button
                  onClick={removeMedia}
                  className="absolute top-1 right-1 bg-black/50 hover:bg-black/70 text-white rounded-full p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
            {selectedVideo && (
              <div className="relative mt-2 inline-block w-full max-w-sm">
                <video src={selectedVideo} className="max-h-48 w-full rounded-lg border border-gray-700" controls />
                <button
                  onClick={removeMedia}
                  className="absolute top-1 right-1 bg-black/50 hover:bg-black/70 text-white rounded-full p-1 z-10"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
        />
        <input
          type="file"
          ref={videoInputRef}
          onChange={handleVideoChange}
          accept="video/*"
          className="hidden"
        />

        <div className="mt-3 flex items-center justify-between">
          <div className="flex gap-4">
            <ActionButton
              icon={<Image className="w-5 h-5 text-blue-400" />}
              label="Media"
              onClick={handleMediaClick}
            />
            <ActionButton
              icon={<Video className="w-5 h-5 text-green-400" />}
              label="Video"
              onClick={handleVideoClick}
            />
            <ActionButton
              icon={<Calendar className="w-5 h-5 text-orange-400" />}
              label="Event"
              onClick={handleEventClick}
            />
          </div>

          <div className="flex gap-2">
            <button
              onClick={handlePolish}
              disabled={isGenerating || !content}
              className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-semi-400 hover:bg-semi-900/30 rounded-md transition-colors disabled:opacity-50"
              title="Polish with AI"
            >
              {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
              <span className="hidden sm:inline">Polish</span>
            </button>
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-purple-400 hover:bg-purple-900/30 rounded-md transition-colors disabled:opacity-50"
            >
              {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
              <span className="hidden sm:inline">Inspire Me</span>
            </button>
            <button
              onClick={handleSubmit}
              disabled={!content.trim() && !selectedImage && !selectedVideo}
              className="flex items-center gap-2 px-4 py-1.5 bg-semi-700 text-white rounded-full font-semibold text-sm hover:bg-semi-800 transition-colors disabled:bg-gray-700 disabled:cursor-not-allowed"
            >
              Post <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const ActionButton: React.FC<{ icon: React.ReactNode; label: string; onClick?: () => void }> = ({ icon, label, onClick }) => (
  <button
    onClick={onClick}
    className="flex items-center gap-2 px-2 py-1 hover:bg-[#252a3a] rounded-md transition-colors cursor-pointer"
  >
    {icon}
    <span className="text-sm font-medium text-gray-400">{label}</span>
  </button>
);

export default CreatePost;
